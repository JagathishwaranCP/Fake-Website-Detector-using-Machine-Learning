from flask import Flask, request, render_template, redirect, url_for
from featureExtractor import featureExtraction
from pycaret.classification import load_model, predict_model
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///url_data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Load ML model
model = load_model('model/phishingdetection')

# Database model
class UrlSubmission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    url = db.Column(db.String(500), nullable=False)
    is_phishing = db.Column(db.Boolean, nullable=False)
    confidence = db.Column(db.Float, nullable=False)
    submission_date = db.Column(db.DateTime, default=datetime.utcnow)
    ip_address = db.Column(db.String(50))

    def __repr__(self):
        return f'<Url {self.url}>'

# Create database tables
with app.app_context():
    db.create_all()

def predict(url):
    data = featureExtraction(url)
    result = predict_model(model, data=data)
    prediction_score = result['prediction_score'][0]  
    prediction_label = result['prediction_label'][0] 
    
    return {
        'prediction_label': prediction_label,
        'prediction_score': prediction_score * 100,
    }

@app.route("/", methods=["GET", "POST"])
def index():
    data = None
    if request.method == "POST":
        url = request.form["url"]
        data = predict(url)
        
        # Save to database
        submission = UrlSubmission(
            url=url,
            is_phishing=data['prediction_label'] == 1,
            confidence=data['prediction_score'],
            ip_address=request.remote_addr
        )
        db.session.add(submission)
        db.session.commit()
        
        return render_template('index.html', url=url, data=data)
    
    return render_template("index.html", data=data)

@app.route("/submissions")
def view_submissions():
    # Get all submissions ordered by date
    submissions = UrlSubmission.query.order_by(UrlSubmission.submission_date.desc()).all()
    return render_template("submissions.html", submissions=submissions)

if __name__ == "__main__":
    app.run(debug=True)